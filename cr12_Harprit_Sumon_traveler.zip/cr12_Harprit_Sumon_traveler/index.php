<?php get_header(); ?>


	<div class="container">
	<h1>POSTS</h1>
	


	<div class="content">
	<?php if(have_posts()) :  ?>
		<?php while(have_posts()) : the_post();	?>


			<div class="card">
	  			<div class="card-header">
	    			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	  			</div>

	  			<ul class="list-group list-group-flush">
	    			<li class="list-group-item"><h6>DATE:</h6><p><?php the_time('F j, Y g:i a'); ?></p></li>
	    			<li class="list-group-item"><h6>Author:</h6><p><?php the_author(); ?></p></li>
	  			</ul>
	  			<p class="box"><?php the_excerpt(); ?></p>
			</div>

			

		<?php endwhile; ?>
		<?php else : ?>
			<?php__('No Posts found'); ?>
		<?php endif; ?>

	</div>

	</div>

	<?php get_footer(); ?>