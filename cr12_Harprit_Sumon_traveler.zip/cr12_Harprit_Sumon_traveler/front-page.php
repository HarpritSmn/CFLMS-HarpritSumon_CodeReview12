<?php get_header(); ?>



<div class="image"><img class="berg" src="https://cdn.pixabay.com/photo/2014/02/28/16/45/mount-everest-276995__480.jpg"></div>
	


<div class="container">

<?php if(have_posts()) :  ?>
		<?php while(have_posts()) : the_post();	?>

			<h2><?php the_title(); ?></h2>
			
			<div class="description"><?php the_content(); ?>
				
			</div>

		<?php endwhile; ?>
		<?php else : ?>
			<?php__('No Posts found'); ?>
		<?php endif; ?>

</div>

<?php get_footer(); ?>